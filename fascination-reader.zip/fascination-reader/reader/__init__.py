"""Fascination Reader application package."""
